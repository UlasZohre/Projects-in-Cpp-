//
// Created by ulasz on 23.12.2022.
//

#ifndef ASM4_PRIMARYAVLNODE_H
#define ASM4_PRIMARYAVLNODE_H


#include <string>
#include "AVL.h"

class PrimaryAVLnode {
public:


    std::string category;

    PrimaryAVLnode* Left;
    PrimaryAVLnode* Right;

    AVL* tree;

    PrimaryAVLnode(const string &cat, AVL* tree_name);

};


#endif //ASM4_PRIMARYAVLNODE_H
