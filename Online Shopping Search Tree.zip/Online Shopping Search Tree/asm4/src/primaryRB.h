//
// Created by ulasz on 23.12.2022.
//

#ifndef ASM4_PRIMARYRB_H
#define ASM4_PRIMARYRB_H


#include "PrimaryRBNode.h"
#include "fstream"
#include "fstream"
using namespace std;
class primaryRB {
public:
    primaryRB();

    PrimaryRBNode* root;

    PrimaryRBNode* find(std::string cat, PrimaryRBNode* start);

    PrimaryRBNode * insert(PrimaryRBNode *root,PrimaryRBNode* add);

    void printLevelOrder(PrimaryRBNode* h, ofstream &output);




};


#endif //ASM4_PRIMARYRB_H
