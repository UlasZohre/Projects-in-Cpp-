//
// Created by ulasz on 19.12.2022.
//

#include "AVLnode.h"


AVLnode::AVLnode(string const& name, int cost){

    product = name;

    price = cost;
    height = 0;

    parent = nullptr;
    left = nullptr;
    right = nullptr;
}
