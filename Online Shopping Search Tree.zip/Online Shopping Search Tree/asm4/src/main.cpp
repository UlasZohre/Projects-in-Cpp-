#include <iostream>
#include "Input.h"



int main(int argc,char** argv) {

    Input::Take_Input(argc, argv);

    return 0;
}
