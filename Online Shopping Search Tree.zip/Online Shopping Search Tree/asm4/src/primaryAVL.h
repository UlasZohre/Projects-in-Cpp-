//
// Created by ulasz on 23.12.2022.
//

#ifndef ASM4_PRIMARYAVL_H
#define ASM4_PRIMARYAVL_H


#include "PrimaryAVLnode.h"
#include "fstream"


class primaryAVL {
public:
    primaryAVL();

    PrimaryAVLnode* root;

    PrimaryAVLnode* find(string cat, PrimaryAVLnode* start);

    PrimaryAVLnode * insert(PrimaryAVLnode *root,PrimaryAVLnode* add);

    void printLevelOrder(PrimaryAVLnode* h, ofstream &output);





};


#endif //ASM4_PRIMARYAVL_H
