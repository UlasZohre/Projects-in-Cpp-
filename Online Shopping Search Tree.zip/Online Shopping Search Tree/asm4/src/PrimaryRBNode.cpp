//
// Created by ulasz on 23.12.2022.
//

#include "PrimaryRBNode.h"

PrimaryRBNode::PrimaryRBNode(const std::string &cat, Tree *tree_name) {
    category = cat;
    Left = nullptr;
    Right = nullptr;

    tree = tree_name;

}
