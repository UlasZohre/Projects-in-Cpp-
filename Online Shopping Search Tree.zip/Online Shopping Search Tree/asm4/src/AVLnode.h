//
// Created by ulasz on 19.12.2022.
//

#ifndef ASM4_AVLNODE_H
#define ASM4_AVLNODE_H

#include <string>


using namespace std;

class AVLnode {

public:

    AVLnode(const string& name, int cost);
    string product;

    int price;
    int height;

    AVLnode* parent ;
    AVLnode* left;
    AVLnode* right;
};


#endif //ASM4_AVLNODE_H
