//
// Created by ulasz on 23.12.2022.
//

#include "queue"

#include <iostream>
#include "RBnode.h"
#include "fstream"
#include "fstream"

class Tree {
private:


    RBnode* rotateLeft(RBnode* h) {
        RBnode* x = h->right;
        h->right = x->left;
        x->left = h;
        x->is_red = h->is_red;
        h->is_red = true;
        return x;
    }

    RBnode* rotateRight(RBnode* h) {
        RBnode* x = h->left;
        h->left = x->right;
        x->right = h;
        x->is_red = h->is_red;
        h->is_red = false;
        return x;
    }

    void flipColors(RBnode* h) {
        if(h){
            h->is_red = !h->is_red;
        }

        if(h->left){
            h->left->is_red= !h->left->is_red;
        }
        if(h->right){
            h->right->is_red = !h->right->is_red;
        }


    }

    RBnode* insert(RBnode* h, std::string key, int cost) {
        if (h == nullptr) {
            return new RBnode(key, cost);
        }
        if (key < h->product) {
            h->left = insert(h->left, key,cost);
        } else if (key > h->product) {
            h->right = insert(h->right, key, cost);
        } else {
            // If the key is already present in the tree, we do nothing
            return h;
        }

        if (isRed(h->right) && !isRed(h->left)) h = rotateLeft(h);
        if (isRed(h->left) && isRed(h->left->left)) h = rotateRight(h);
        if (isRed(h->left) && isRed(h->right)) flipColors(h);

        return h;
    }

    bool isRed(RBnode* x) {
        if (x == nullptr) return false;
        return x->is_red == true;
    }
    RBnode *find(std::string cat, RBnode* start) {
        RBnode* temp = start;
        std::cout << "tree 65 " << start << std::endl;

        RBnode* conclusion = nullptr;

        if ( temp == nullptr){
            return conclusion;
        }

        int comp = cat.compare(temp->product);

        if (comp < 0){
            conclusion = find(cat, start->left);
        }

        else if(comp == 0){
            conclusion = temp;
        }

        else{
            conclusion = find(cat, start->right);
        }

        return conclusion;

    }



    RBnode* moveRedLeft(RBnode* h) {
        flipColors(h);
        if (isRed(h->right->left)) {
            h->right = rotateRight(h->right);
            h = rotateLeft(h);
            flipColors(h);
        }
        return h;
    }

    RBnode* moveRedRight(RBnode* h) {
        flipColors(h);

        if (h->left && isRed(h->left->left )) {
            h = rotateRight(h);
            flipColors(h);
        }
        return h;
    }

    RBnode* deleteMin(RBnode* h) {
        if (h->left == nullptr) return nullptr;
        if (!isRed(h->left) && !isRed(h->left->left)) h = moveRedLeft(h);
        h->left = deleteMin(h->left);
        return balance(h);
    }

    RBnode* balance(RBnode* h) {
        if (isRed(h->right)) h = rotateLeft(h);
        if (isRed(h->left) && isRed(h->left->left)) h = rotateRight(h);
        if (isRed(h->left) && isRed(h->right)) flipColors(h);
        return h;
    }

    RBnode* deleteKey(RBnode* h, std::string key) {
        if (key < h->product) {
            if (!isRed(h->left) && !isRed(h->left->left)) h = moveRedLeft(h);
            h->left = deleteKey(h->left, key);
        } else {
            if (isRed(h->left)) h = rotateRight(h);
            if (key == h->product && h->right == nullptr) return nullptr;
            if (!isRed(h->right) && !isRed(h->right->left)) h = moveRedRight(h);
            if (key == h->product) {
                RBnode* x = min(h->right);
                h->product = x->product;
                h->right = deleteMin(h->right);
            } else {
                h->right = deleteKey(h->right, key);
            }
        }
        return balance(h);
    }

    RBnode* min(RBnode* h) {
        if (h->left == nullptr) return h;
        return min(h->left);
    }



public:
    RBnode* root;
    Tree() : root(nullptr) {}

    void printLevelOrder(RBnode* h, std::ofstream &output) {
        if (h == nullptr) return;
        std::queue<RBnode*> q;
        q.push(h);
        int level = 0;

        while (!q.empty()) {
            int size = q.size();
            output << "\t";
            while (size > 0) {
                RBnode* x = q.front();
                q.pop();
                output <<"\""<< x->product <<"\""<< " "<<":\""<<x->price<<"\"";
                if (x->left != nullptr) q.push(x->left);
                if (x->right != nullptr) q.push(x->right);
                size--;
            }
            output << std::endl;
            level++;
        }
        output << std::endl;
    }

    void insert(std::string key, int cost) {
        root = insert(root, key, cost);
        root->is_red= false;
    }

    RBnode* find(std::string cat){
        find(cat, root);
    }


    void print_all_items(std::fstream &output) {

    }

    void deleteKey(std::string key) {
        std::cout << "rb 191" << std::endl;
        if (!isRed(root->left) && !isRed(root->right)) root->is_red = true;
        root = deleteKey(root, key);
        if (root != nullptr) root->is_red= false;
    }

};




