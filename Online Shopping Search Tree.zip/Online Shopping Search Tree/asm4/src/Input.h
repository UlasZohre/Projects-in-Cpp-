//
// Created by ulasz on 19.12.2022.
//

#ifndef ASM4_INPUT_H
#define ASM4_INPUT_H
#include "iostream"

class Input {

public:
    static void Take_Input(int argc, char**argv);

};


#endif //ASM4_INPUT_H
