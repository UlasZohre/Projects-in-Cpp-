//
// Created by ulasz on 20.12.2022.
//

#ifndef ASM4_AVL_H
#define ASM4_AVL_H
#include "fstream"
#include "AVLnode.h"
#include "fstream"


using namespace std;
class AVL {

public:

    AVL();

    AVLnode* root;

    int max(int a, int b);

    int Height(AVLnode* temp);

    AVLnode* right_rotate(AVLnode* temp);

    AVLnode* left_rotate(AVLnode* temp);

    int balance_factor(AVLnode* temp);

    AVLnode* insert(AVLnode* node, AVLnode* add);

    AVLnode* min_value_product(AVLnode* start);

    AVLnode *deleteNode(AVLnode *root, string key);

    AVLnode *minValueNode(AVLnode *node);

    AVLnode* find(string cat, AVLnode* start);

    void printTree(AVLnode* start, ofstream &output);
};


#endif //ASM4_AVL_H
