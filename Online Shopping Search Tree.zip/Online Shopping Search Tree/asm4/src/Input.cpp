//
// Created by ulasz on 19.12.2022.
//

#include "Input.h"

#include <sstream>
#include <vector>
#include "AVL.h"
#include "AVLnode.h"
#include "primaryAVL.h"
#include "PrimaryAVLnode.h"
#include "RBnode.h"
#include "PrimaryRBNode.h"
#include "primaryRB.h"

using namespace std;
/*using std::string;
using std::fstream;
using std::cout;
using std::endl;*/


void Input::Take_Input(int argc, char**argv) {

    ofstream output;
    ofstream output1;
    fstream input;

    input.open(argv[1]);

    output.open(argv[2]);

    output1.open(argv[3]);

    if (!input.is_open()){
        cout << "ınput could not open." << endl;
        return;
    }

    if (!output.is_open()) {
        cout << "output could not open" << endl;
        return;
    }

    if(!output1.is_open()){
        cout << "output1 could not open" << endl;
    }

    auto* PrimaryAVL = new primaryAVL;
    auto* PrimaryRB = new primaryRB;

    string line;
    string item;

    while (getline(input, line)){

        vector<string> commands(4);
        stringstream ss(line);
        int index = 0;
        while(getline(ss, item, '\t')){

            commands[index] = item;
            index++;
        }

        /* commands.at(0) = action
         * commands.at(1) = category
         * commands.at(2) = product
         * commands.at(3) = price */

        if (commands.at(0) == "insert"){

            PrimaryAVLnode* temp_avl = PrimaryAVL->find(commands.at(1), PrimaryAVL->root);

            if(!temp_avl){
                auto* temp_tree = new AVL();
                auto* temp_node = new PrimaryAVLnode(commands.at(1), temp_tree);
                PrimaryAVL->root = PrimaryAVL->insert(PrimaryAVL->root, temp_node);
                temp_avl = temp_node;
            }

            auto* temp_product_avl = new AVLnode(commands.at(2), stoi(commands.at(3)));

            temp_avl->tree->root = temp_avl->tree->insert(temp_avl->tree->root, temp_product_avl);

            PrimaryRBNode* temp_rb = PrimaryRB->find(commands.at(1), PrimaryRB->root);

            if(!temp_rb){
                auto* temp_tree = new Tree();
                auto* temp_node = new PrimaryRBNode(commands.at(1), temp_tree);
                PrimaryRB->root = PrimaryRB->insert(PrimaryRB->root, temp_node);
                temp_rb = temp_node;
            }
            temp_rb->tree->insert(commands.at(2), stoi(commands.at(3)));

        }

        else if (commands.at(0) == "printAllItems") {

            output << "command" << ":" << commands.at(0) << "\n{\n";
            PrimaryAVL->printLevelOrder(PrimaryAVL->root, output);
            output <<"\n}\n";

            output1 << "command" << ":" << commands.at(0) << "\n{\n";

            PrimaryRB->printLevelOrder(PrimaryRB->root, output1);
            output1 << "\n}\n";
        }

        else if (commands.at(0) == "updateData"){

            auto* temp_avl = PrimaryAVL->find(commands.at(1), PrimaryAVL->root);

            auto* temp_avl_second = temp_avl->tree->find(commands.at(2), temp_avl->tree->root);

            temp_avl_second->price = stoi(commands.at(3));

            PrimaryRBNode* temp_rb = PrimaryRB->find(commands.at(1), PrimaryRB->root);

            RBnode* temp_rb_second =temp_rb->tree->find(commands.at(2));

            temp_rb_second->price = stoi(commands.at(3));

        }

        else if (commands.at(0) == "printItem"){

            PrimaryAVLnode* temp_prima_avl = PrimaryAVL->find(commands.at(1), PrimaryAVL->root);
            AVLnode* temp_avl = temp_prima_avl->tree->find(commands.at(2), temp_prima_avl->tree->root);
            if (temp_avl != nullptr)
                output << "command:" << commands.at(0) << "\t"  << temp_prima_avl->category  << "\t" << temp_avl->product << "\n{}\n";

            PrimaryRBNode* temp_prima_rb = PrimaryRB->find(commands.at(1), PrimaryRB->root);
            RBnode* temp_rb = temp_prima_rb->tree->find(commands.at(2));

            if (temp_rb != nullptr)
                output1 << "command:" << commands.at(0) << "\t"  << temp_prima_rb->category  << "\t" << temp_rb->product << "\n{}\n";
        }

        else if (commands.at(0) == "remove"){

            PrimaryAVLnode* temp_prima_avl = PrimaryAVL->find(commands.at(1), PrimaryAVL->root);


            temp_prima_avl->tree->root = temp_prima_avl->tree->deleteNode(temp_prima_avl->tree->root, commands.at(2));


            PrimaryRBNode* temp_prima_rb = PrimaryRB->find(commands.at(1), PrimaryRB->root);
            cout << "input 149 " << temp_prima_rb << " category: " << commands.at(2) << endl;
            cout << "input 147 " << PrimaryRB->root->category << endl;

            temp_prima_rb->tree->deleteKey(commands.at(2));

        }

        else if (commands.at(0) == "printAllItemsInCategory"){

            PrimaryAVLnode* temp_prima_avl = PrimaryAVL->find(commands.at(1), PrimaryAVL->root);
            output <<"command" << ":" <<commands.at(0) << "\t" << temp_prima_avl->category;
            temp_prima_avl->tree->printTree(temp_prima_avl->tree->root, output);

            PrimaryRBNode* temp_prima_rb = PrimaryRB->find(commands.at(1), PrimaryRB->root);
            output1 <<"command" << ":" <<commands.at(0) << "\t" << temp_prima_rb->category << "\n{\n";
            temp_prima_rb->tree->printLevelOrder(temp_prima_rb->tree->root, output1);
            output1<<"\n}\n";

        }

        else if (commands.at(0) == "find"){


            PrimaryAVLnode* temp_prima_avl = PrimaryAVL->find(commands.at(1), PrimaryAVL->root);
            AVLnode *temp_avl = nullptr;
            if(temp_prima_avl != nullptr){
                 temp_avl = temp_prima_avl->tree->find(commands.at(2), temp_prima_avl->tree->root);
            }

            if(temp_avl){
                output << "command:" << commands.at(0) << "\t"  << temp_prima_avl->category  << "\t" << temp_avl->product << "\n{}\n";
            }


            PrimaryRBNode* temp_prima_rb = PrimaryRB->find(commands.at(1),PrimaryRB->root);
            RBnode *temp_rb = nullptr;
            if(temp_prima_rb){
                temp_rb = temp_prima_rb->tree->find(commands.at(2));
            }

            if(temp_rb){
                output1 << "command:" << commands.at(0) << "\t"  << temp_prima_rb->category  << "\t" << temp_rb->product << "\n{}\n";
            }

        }

    }

    input.close();
    output.close();
    output1.close();
}
