//
// Created by ulasz on 23.12.2022.
//

#ifndef ASM4_TREE_H
#define ASM4_TREE_H
#include "RBnode.h"
#include "fstream"
#include "iostream"
using namespace std;

class Tree {
public:
    RBnode *root;


    RBnode* rotateRight(RBnode *node);

    RBnode* rotateLeft(RBnode *node);
    void flipColors(RBnode* h);

    RBnode* insert(RBnode* h, string key, int cost);
    void remove(RBnode *&start, std::string &product);


    Tree();
    void insert(string key, int cost);
    void remove(std::string del);
    RBnode* find(std::string cat, RBnode* start);
    void print_all_items(fstream &output);


    static void print_level_order(RBnode* start, fstream &output);
};


#endif //ASM4_TREE_H
