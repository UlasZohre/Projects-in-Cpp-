//
// Created by ulasz on 23.12.2022.
//

#include "RBnode.h"

RBnode::RBnode(std::string &product_name, int cost) {
    product = product_name;
    price = cost;
    is_red = true;
    left = nullptr;
    right = nullptr;

}
