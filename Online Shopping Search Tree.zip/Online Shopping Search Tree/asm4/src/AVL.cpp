//
// Created by ulasz on 20.12.2022.
//

#include "AVL.h"
#include "iostream"
#include "queue"

AVL::AVL() {

    root = nullptr;

}


int AVL::max(int a, int b) {
    return (a > b ) ? a : b;
}

int AVL::Height(AVLnode *temp) {
    if( temp == nullptr){
        return 0;
    }
    return temp->height;
}

AVLnode *AVL::right_rotate(AVLnode *temp) {

    AVLnode* current = temp->left;
    AVLnode* current2 = current->right;

    current->right = temp;
    temp->left = current2;

    temp->height = max(Height(temp->left), Height(temp->right)) +1;
    current->height = max(Height(current->left), Height(current->right)) +1;

    return current;
}

AVLnode *AVL::left_rotate(AVLnode* temp) {

    AVLnode* current = temp->right;
    AVLnode* current2 = current->left;

    current->left = temp;
    temp->right = current2;

    temp->height = max(Height(temp->right), Height(temp->left)) +1;
    current->height = max(Height(current->right), Height(current->left)) + 1;

    return current;
}

int AVL::balance_factor(AVLnode *temp) {

    if (temp == nullptr){
        return 0;
    }

    return Height(temp->left) - Height(temp->right);
}

AVLnode *AVL::insert(AVLnode* node, AVLnode* add) {
    AVLnode* start = node;
    if(start == nullptr){
        return add;
    }

    int comp = add->product.compare(start->product);
    if (comp < 0){
        start->left = insert(node->left, add);
    }

    else if( comp > 0){
        start->right = insert(node->right, add);
    }

    else{
        return start;
    }

    start->height = max(Height(start->right), Height(start->left)) + 1;
    int balance = balance_factor(start);

    if (balance > 1){
        int comp2 = add->product.compare(start->left->product);
        if(comp2 < 0 ){
            return right_rotate(start);
        }

        else if ( comp2 > 0){
            start->left = left_rotate(start->left);
            return right_rotate(start);
        }
    }

    if (balance < -1 ){
        int comp2 = add->product.compare(start->right->product);
        if (comp2 > 0){
            return left_rotate(start);
        }
        else if(comp < 0){
            start->right = right_rotate(start->right);
            return left_rotate(start);
        }
    }
    return start;
}

AVLnode *AVL::min_value_product(AVLnode *start) {
    AVLnode *current = start;
    while(current->left != nullptr){
        current = current->left;
    }
    return current;
}


// A utility function to find the node with minimum
// key value (used in deleteNode)
AVLnode *AVL::minValueNode(AVLnode *node)
{
    AVLnode *current = node;

    /* loop down to find the leftmost leaf */
    while (current->left != nullptr)
        current = current->left;

    return current;
}

// Recursive function to delete a node with given key
// from subtree with given root. It returns root of
// the modified subtree.
AVLnode *AVL::deleteNode(AVLnode *root, string key)
{
    // STEP 1: PERFORM STANDARD BST DELETE

    if (root == nullptr)
        return root;

    // If the key to be deleted is smaller than the
    // root's key, then it lies in left subtree
    if (key < root->product)
        root->left = deleteNode(root->left, key);

        // If the key to be deleted is greater than the
        // root's key, then it lies in right subtree
    else if (key > root->product)
        root->right = deleteNode(root->right, key);

        // if key is same as root's key, then this is
        // the node to be deleted
    else
    {
        // node with only one child or no child
        if ((root->left == nullptr) ||
            (root->right == nullptr))
        {
            AVLnode *temp = root->left ?
                         root->left :
                         root->right;

            // No child case
            if (temp == nullptr)
            {
                temp = root;
                root = nullptr;
            }
            else // One child case
                *root = *temp; // Copy the contents of
            // the non-empty child
            delete temp;
        }
        else
        {
            // node with two children: Get the inorder
            // successor (smallest in the right subtree)
            AVLnode *temp = minValueNode(root->right);

            // Copy the inorder successor's data to this node
            root->product = temp->product;

            // Delete the inorder successor
            root->right = deleteNode(root->right,
                                     temp->product);
        }
    }

    // If the tree had only one node then return
    if (root == nullptr)
        return root;

    // STEP 2: UPDATE HEIGHT OF THE CURRENT NODE
    root->height = 1 + max(Height(root->left),
                           Height(root->right));

    // STEP 3: GET THE BALANCE FACTOR OF THIS NODE (to
    // check whether this node became unbalanced)
    int balance = balance_factor(root);

    // If this node becomes unbalanced, then there are 4 cases

    // Left Left Case
    if (balance > 1 &&
        balance_factor(root->left) >= 0)
        return right_rotate(root);

    // Left Right Case
    if (balance > 1 &&
        balance_factor(root->left) < 0)
    {
        root->left = left_rotate(root->left);
        return right_rotate(root);
    }

    // Right Right Case
    if (balance < -1 &&
        balance_factor(root->right) <= 0)
        return left_rotate(root);

    // Right Left Case
    if (balance < -1 &&
        balance_factor(root->right) > 0)
    {
        root->right = right_rotate(root->right);
        return left_rotate(root);
    }
    return root;
}


AVLnode *AVL::find(string cat, AVLnode* start) {
   AVLnode* temp = start;

   AVLnode* conclusion = nullptr;

    if ( temp == nullptr){
        return conclusion;
    }

    int comp = cat.compare(temp->product);

    if (comp < 0){
        conclusion = find(cat, start->left);

    }

    else if(comp == 0){
        conclusion = temp;

    }

    else{
        conclusion = find(cat, start->right);

    }

    return conclusion;

}

void AVL::printTree(AVLnode* h, ofstream &output) {
    if (h == nullptr){
        output << "{}\n";
        return;
    }
    std::queue<AVLnode*> q;
    q.push(h);
    int level = 0;
    while (!q.empty()) {
        int size = q.size();
        output << "\t";
        while (size > 0) {
            AVLnode* x = q.front();
            q.pop();
            output <<"\""<< x->product <<"\""<< " "<<":\""<<x->price<<"\"\n";
            if (x->left!= nullptr) q.push(x->left);
            if (x->right != nullptr) q.push(x->right);
            size--;
            output << "\t";
        }
        output << std::endl;
        level++;
    }
    output << std::endl;


}


