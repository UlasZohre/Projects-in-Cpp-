//
// Created by ulasz on 23.12.2022.
//

#include "primaryRB.h"
#include "iostream"
#include "queue"

primaryRB::primaryRB() {
    root = nullptr;

}
PrimaryRBNode *primaryRB::find(string cat,PrimaryRBNode* start) {

    PrimaryRBNode* temp = start;

    PrimaryRBNode* conclusion = nullptr;

    if ( temp == nullptr){

        return conclusion;
    }
    int comp = cat.compare(temp->category);

    if (comp < 0){
        conclusion = find(cat, temp->Left);


    }
    else if(comp == 0){
        conclusion = temp;


    }
    else{

        conclusion = find(cat, temp->Right);

    }

    return conclusion;
}

PrimaryRBNode * primaryRB::insert(PrimaryRBNode *root, PrimaryRBNode *add) {
    PrimaryRBNode* temp = root;

    if (root == nullptr){
        return add;
    }

    int comp = add->category.compare(temp->category);

    if (comp <0){
        temp->Left = insert(temp->Left, add);
    }

    else if(comp > 0){
        temp->Right = insert(temp->Right, add);
    }


    return temp;

}

void primaryRB::printLevelOrder(PrimaryRBNode *h, ofstream &output) {
    if (h == nullptr) return;
    std::queue<PrimaryRBNode*> q;
    q.push(h);
    int level = 0;
    while (!q.empty()) {
        int size = q.size();
        while (size > 0) {
            PrimaryRBNode* x = q.front();
            q.pop();
            output << "\""<<x->category << "\":\n";
            x->tree->printLevelOrder(x->tree->root, output);
            if (x->Left != nullptr) q.push(x->Left);
            if (x->Right != nullptr) q.push(x->Right);
            size--;
        }
        output << std::endl;
        level++;
    }
    output << std::endl;

}


