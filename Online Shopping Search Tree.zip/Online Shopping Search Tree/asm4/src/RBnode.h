//
// Created by ulasz on 23.12.2022.
//

#ifndef ASM4_RBNODE_H
#define ASM4_RBNODE_H
#include "iostream"

class RBnode {
public:
    std::string product;
    int price;
    bool is_red;
    RBnode* left;
    RBnode* right;

    RBnode(std::string &product_name, int cost);

};


#endif //ASM4_RBNODE_H
