//
// Created by ulasz on 23.12.2022.
//

#include "PrimaryAVLnode.h"

PrimaryAVLnode::PrimaryAVLnode(const string &cat, AVL *tree_name) {

    category = cat;
    Left = nullptr;
    Right = nullptr;

    tree = tree_name;


}
