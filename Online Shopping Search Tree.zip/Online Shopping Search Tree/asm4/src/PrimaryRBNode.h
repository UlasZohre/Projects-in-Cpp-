//
// Created by ulasz on 23.12.2022.
//

#ifndef ASM4_PRIMARYRBNODE_H
#define ASM4_PRIMARYRBNODE_H



#include "Tree.cpp"



class PrimaryRBNode {
public:
    std::string category;

    PrimaryRBNode* Left;
    PrimaryRBNode* Right;

    Tree* tree;

    PrimaryRBNode(const std::string &cat, Tree* tree_name);
};


#endif //ASM4_PRIMARYRBNODE_H
