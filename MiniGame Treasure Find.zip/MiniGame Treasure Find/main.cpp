#include <iostream>
#include <fstream>
#include <string>


using namespace std;


void splitX(string mapsize, int* row, int *column){

    string temp_row { " "};// temp variables to contain char values until converting to int
    string temp_column {" "};

    const char x {'x'};//to understand x

    for (int i = 0; i <(int)mapsize.size(); i++){

        if (mapsize[i] != x){
            temp_row += mapsize[i];//it will add in temp_row until it finds a x

        }
        else if (mapsize[i] == x){
            for (int j = i + 1; j < (int)mapsize.size(); j++){
                if (mapsize[j] != x){//after finding x first time it will start add to column
                    temp_column += mapsize[j];
                }
                i = j;// we want to exit from for cycle
            }
        }
    }
    *row = stoi(temp_row);//converting to int
    *column = stoi(temp_column);

}

void split(int** array,string line, int row_no){
    int char_size;
    int column_no {0};//columns must be restarted for every row
    string temp_str {};

    for ( char_size = 0; char_size < (int) line.size(); char_size++){

        if (line[char_size] != ' '){
            temp_str += line[char_size];//will add the characters until find a gap
        }
        if(line[char_size] == ' '|| char_size == line.length() -1 ){
            array[row_no][column_no] = stoi(temp_str);
            temp_str = "";// after find a gap it will convert and add it to array
            column_no++;
        }
    }


}

void treasureFind(int** map, int** key, int key_size, int start_x, int start_y, int row_num, int col_num,
                  fstream &output){

    /* 0 found treasure
     * 1 go up
     * 2 go down
     * 3 go right
     * 4 go left
     */

    int total{0};

    int i = 0;

    while ( i < key_size){
        for (int j = 0; j < key_size; j++){
            total += map[start_x + i][start_y+j] * key[i][j];
        }
        i++;
    }

    output << start_x+1 << "," << start_y+1 << ":" << total <<endl;

    int outcome = total % 5;

    if (outcome < 0){
        outcome = outcome + 5;
    }

    if (outcome == 1){//go up
        if (start_x - key_size < 0){
            treasureFind(map,key,key_size,start_x + key_size,start_y, row_num,col_num,output);
        }
        else{
            treasureFind(map,key,key_size,start_x - key_size,start_y, row_num, col_num,output);
        }
    }

    else if(outcome == 2){// go down
        if (start_x + key_size > row_num){
            treasureFind(map, key,key_size, start_x - key_size, start_y, row_num, col_num,output);
        }
        else{
            treasureFind(map,key,key_size, start_x+key_size, start_y, row_num, col_num,output);
        }
    }

    else if(outcome == 3){// go right
        if ( start_y + key_size > col_num){
            treasureFind(map,key,key_size,start_x,start_y-key_size,row_num,col_num,output);
        }
        else{
            treasureFind(map,key,key_size,start_x, start_y+ key_size, row_num, col_num,output);
        }

    }

    else if (outcome == 4){// go left

        if(start_y - key_size < 0){
            treasureFind(map,key,key_size, start_x, start_y + key_size, row_num, col_num,output);
        }
        else{
            treasureFind(map,key,key_size,start_x , start_y- key_size, row_num, col_num, output);
        }

    }

    else{

        cout << total <<" "<<total%5<<  endl;
        cout << "You win." << endl;
        return;
    }


    cout << total <<" "<<total%5<<  endl;

}

int main(int argc, char* argv[]) {

    /* argv[0] find treasure
     * argv[1] map size
     * argv[2] key matrix size
     * argv[3] map matrix.txt
     * argv[4] key matrix.txt
     * argv[5] output.txt
     */

    int row_number {18}; // argv[1] den ayırıp bunlara atayacaksın ve 18 leri sıfır yapacaksın
    int column_number {18};


    //string mapsize (argv[1]);

    //splitX(mapsize,&row,&column);

    ifstream mapMatrix;
    mapMatrix.open("../mapmatrix1");// with or without txt? argv[3] diyeceksin

    int **map;
    map = new int*[row_number];
    for( int i = 0; i < row_number; i++ ){
        map[i] = new int[column_number] {0};//2d dynamic array all 0.

    }

    if (!mapMatrix.is_open()){
        cout << "File not opened." << endl;//if it is not open it will tell us and return 1
        return 1;
    }

    string line {};// to read file

    int row_no {0};

    while(getline(mapMatrix, line)){

        split(map, line, row_no);
        row_no++;
    }

    mapMatrix.close();

    int keymatrixsize {3};
    // int keymatrixsize = argv[2]



    int** key;
    key = new int*[keymatrixsize];
    for (int i = 0; i < keymatrixsize; i++ ){
        key[i] = new int[keymatrixsize]{0};
    }

    ifstream keyMatrix;
    keyMatrix.open("../keymatrix1");// argv[4] olacak

    if (!keyMatrix.is_open()){
        cout << "KeyMatrix file not opened." << endl;
    }

    row_no = 0;

    while (getline(keyMatrix, line)){

        split(key,line, row_no);
        row_no++;
    }

    keyMatrix.close();


    fstream output;
    output.open(argv[5]);

    treasureFind(map,key,keymatrixsize,0,0, row_number, column_number,output);

    for(int i = 0; i < row_number; i++){//prints array will be deleted

        for(int j = 0; j < column_number; j++){

            cout << map[i][j] << " ";
        }
        cout << endl;
    }

    cout << endl << endl;

    for (int i = 0; i < keymatrixsize; i++){
        for (int j = 0; j < keymatrixsize; j++){
            cout << key[i][j] << " ";
        }
        cout << endl;
    }

    delete(map);
    return 0;
}
