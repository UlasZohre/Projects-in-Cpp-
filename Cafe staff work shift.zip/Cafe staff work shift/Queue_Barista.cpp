//
// Created by ulasz on 3.12.2022.
//

#include "Queue_Barista.h"
#include <iostream>
using namespace std;

Queue_Barista::Queue_Barista() {
    size = 0;
    max_size = 0;
    Head = nullptr;
    Last = nullptr;
}


Customer* Queue_Barista::pop() {

    Customer* temp = Head;

    if(Head == nullptr){
        return nullptr;
    }

    else{
        if (Head->next != nullptr) {
            Head = Head->next;
        }

        else{
            Head = nullptr;
            Last = nullptr;
        }
    }


    size--;
    return temp;
}

void Queue_Barista::emplace(Customer* cust) {

    if ( Head == nullptr){
        Head = cust;
        Last = cust;
    }

    else if(cust->order_price > Head->order_price){

        cust->next = Head;
        Head = cust;
    }

    else if (cust->order_price < Last->order_price){

        Last->next = cust;
        Last = cust;
    }

    else{
        Customer* prev = Head;
        Customer* curr = Head->next;

        while (curr != nullptr && (cust->order_price > prev->order_price || cust->order_price < curr->order_price))
        {
            prev = curr;
            curr = curr->next;
        }

        if (curr == nullptr)
        {
            Last->next = cust;
            Last = cust;
        }
        else
        {
            prev->next = cust;
            cust->next = curr;
        }

    }

    size++;//updating size

    if (size > max_size){//updating max size if this is true
        max_size =size;
    }
}