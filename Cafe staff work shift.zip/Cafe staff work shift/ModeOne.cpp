//
// Created by ulasz on 6.12.2022.
//
#include "algorithm"
#include "ModeOne.h"
bool CompareCustomer(Customer *cust1, Customer *cust2) {
    return (cust1->arriving_barista_time < cust2->arriving_barista_time);
}

Staff* find_next_barista(vector<Staff*> barista_list){
    Staff* temp = barista_list[0];
    for (auto barista: barista_list){
        if (temp->time_until_avail> barista->time_until_avail){
            temp = barista;
        }
    }

    return temp;
}

ModeOne::ModeOne(fstream &input, fstream &output) {

    int counter = 0;
    int cashier_count = 0;
    int order_count = 0;
    vector<Customer*> customers;

    double temp = 0;
    double arrival_time_in;
    double order_time_in;
    double brew_time_in;
    double order_price_in;


    while (input >> temp){

        if(counter == 0){
            cashier_count = temp;
        }

        else if ( counter == 1){
            order_count = temp;
        }

        else{

            arrival_time_in = temp;
            input >> order_time_in >> brew_time_in  >> order_price_in;
            auto *new_customer = new Customer( arrival_time_in, order_time_in, brew_time_in, order_price_in);

            customers.push_back(new_customer);// temporary we will send them to queue

        }
        counter++;
    }

    vector<Staff*> cashier_list;//cashiers will be here

    for (int i = 0; i < cashier_count; i++){

        auto *cashier = new Staff;
        cashier_list.push_back(cashier);
    }

    vector <Staff*> barista_list;//baristas will be here

    for (int i = 0; i <(cashier_count/3); i++){

        auto *barista = new Staff;
        barista_list.push_back(barista);
    }

    vector<double> time_flow;//an easier way to follow timeline

    for (int i = 0; i < customers.size(); i++){//we will get customers' arrival times and take their gap

        if (i == 0){
            time_flow.push_back(customers[i]->arrival_time);//adding them to vector
        }

        else{
            time_flow.push_back(customers[i]->arrival_time - customers[i-1]->arrival_time);//adding them to vector
        }
    }
    Queue_Cashier queueCashier = Queue_Cashier();//creating new cashier queue
    Queue_Barista queueBarista = Queue_Barista();//creating new barista queue

    for (int in_customer = 0; in_customer < customers.size(); in_customer++ ){// iterating every customer to see if there is an available cashier

        double waiting_time {0};//their default waiting time, we can not know its exact value until iteration complete

        for (auto & in_cashier : cashier_list){//iterating on cashier to see minimum waiting time

            if (in_cashier->time_until_avail >= 0 ){//if cashier need some time to become available
                in_cashier->time_until_avail -= time_flow[in_customer];//time will advance so s/he will need less time
                waiting_time = in_cashier->time_until_avail;//updating waiting time for all cashiers if customer needs to wait

                if (in_cashier->time_until_avail <= 0) {//time until avail can not be less than zero
                    in_cashier->time_until_avail = 0;
                    in_cashier->is_avail = true;//while time advance if avail time is less than zero they should become avail
                }
            }

            if (customers[in_customer]->waiting_time_change_cashier == 0){

                customers[in_customer]->waiting_time = waiting_time;
                customers[in_customer]->waiting_time_change_cashier++;

            }

            else if(waiting_time < customers[in_customer]->waiting_time ){// customer waits minimum waiting time so we need to take that
                customers[in_customer]->waiting_time = waiting_time;

            }
        }

        for (auto in_cashier : cashier_list) {//iterating cashiers to see if there is someone avail
            if (in_cashier->is_avail) {

                in_cashier->working_time += customers[in_customer]->order_time;//total working time is updated
                in_cashier->is_avail = false;//cashier is not avail now
                in_cashier->time_until_avail = customers[in_customer]->order_time;
                // cashier needs to wait customer to take their order
                customers[in_customer]->waiting_time = 0;//we ll make waiting time zero if someone available since they do not wait at all
                break;
            }
        }


        if (customers[in_customer]->waiting_time > 0){//if waiting time is greater than zero than that means there is no available cashiers customer
            // will need to wait in queue
            queueCashier.emplace(customers[in_customer]);

        }

        if (in_customer + 1 < customers.size()){
            if (customers[in_customer]->waiting_time + customers[in_customer]->arrival_time <
                customers[in_customer + 1]->arrival_time && queueCashier.size > 0){//if current customer's waiting time plus arrival time is less than next customer arrival time
                time_flow[in_customer +1] -= customers[in_customer]->waiting_time;
                for (auto in_cashier : cashier_list){//we will advance timeline once again according to waiting time

                    if (in_cashier->time_until_avail >= 0){
                        in_cashier->time_until_avail -= customers[in_customer]->waiting_time;

                        if (in_cashier->time_until_avail <= 0){
                            in_cashier->time_until_avail = 0;
                            in_cashier->is_avail = true;
                        }
                    }
                }


                for (auto in_cashier : cashier_list) {//checking cashier again one must be available right now
                    if (in_cashier->is_avail) {
                        in_cashier->working_time += customers[in_customer]->order_time;
                        in_cashier->is_avail = false;
                        in_cashier->time_until_avail = customers[in_customer]->order_time;
                        queueCashier.pop();
                        break;
                    }
                }
            }
        }
    }

    if (queueCashier.size > 0){
        while (queueCashier.Head != nullptr){
            for (auto cashier: cashier_list){
                if(cashier->time_until_avail >= 0){
                    cashier->time_until_avail -= queueCashier.Head->waiting_time;


                    if (cashier->time_until_avail <= 0){
                        cashier->time_until_avail = 0;
                        cashier->is_avail = true;
                    }
                }
            }

            for (auto cashier: cashier_list){
                if (cashier->is_avail){
                    cashier->working_time += queueCashier.Head->order_time;
                    cashier->is_avail = false;
                    cashier->time_until_avail = queueCashier.Head->order_time;
                    queueCashier.pop();
                    break;

                }
            }
        }
    }



    vector <Customer*> barista_customers;
    vector<double> time_flow_barista;

    for (auto cust :customers){
        cust->arriving_barista_time = cust->arrival_time + cust->waiting_time +cust->order_time;
        barista_customers.push_back(cust);
    }

    sort(barista_customers.begin(), barista_customers.end(), CompareCustomer);

    for (auto barista_customer : barista_customers){

        if(!barista_customer->customer_in_queue){
            queueBarista.emplace(barista_customer);
            barista_customer->customer_in_queue = true;
        }


        for (int barista = 0; barista < barista_list.size() ; barista++){
            if (barista_list[barista]->is_avail){

                barista_list[barista]->is_avail = false;
                barista_list[barista]->working_time += barista_customer->brew_time;
                barista_list[barista]->time_until_avail = barista_customer->brew_time + barista_customer->arriving_barista_time;
                barista_customer->customer_took_its_order = barista_list[barista]->time_until_avail;
                barista_customer->barista_id = barista;

                if (barista_list[barista]->work_start == 0){
                    barista_list[barista]->work_start = barista_customer->arriving_barista_time;
                }
                queueBarista.pop();
                break;
            }
        }

        if (queueBarista.size > 0){
            Staff* next_barista = find_next_barista(barista_list);


            for (auto customer: barista_customers){

                if (customer->customer_in_queue){
                    continue;
                }

                else if (customer->arriving_barista_time < next_barista->time_until_avail){

                    queueBarista.emplace(customer);
                    customer->customer_in_queue = true;
                }

                else{
                    break;
                }
            }

            Customer* current = queueBarista.Head;

            for (int barista= 0 ; barista < barista_list.size(); barista++){
                if (next_barista == barista_list[barista]){
                    current->barista_id = barista;
                }
            }

            current->barista_waiting_time = next_barista->time_until_avail - current->arriving_barista_time;


            next_barista->is_avail = false;
            next_barista->working_time += current->brew_time;
            next_barista->time_until_avail = current->brew_time + current->arriving_barista_time
                                             + current->barista_waiting_time;

            queueBarista.pop();
            current->customer_took_its_order = next_barista->time_until_avail;


        }
    }

    double total_barista_working_time {0};
    double total_work_start = 0;


    cout << " 283 queue barista max size: " << queueBarista.max_size << endl;
    for (auto barista: barista_list){
        cout << " 332 barista working start : " << barista->work_start << endl;
        cout << " 333 barista working time : " << barista->working_time << endl;
        total_barista_working_time += barista->working_time;
        total_work_start += barista->work_start;
    }
    double total_brew_time = 0;
    for (auto cust : customers){
        total_brew_time += cust->brew_time;
    }

    cout << "total brew time : " << total_brew_time << endl;
    cout << "total barista working time : " << total_barista_working_time << endl;

    for (auto customer : barista_customers){
        cout << "barista arriving time :" << customer->arriving_barista_time << endl;
        cout << "barista id : " << customer->barista_id << endl;
        cout  << endl;
    }

    double total_running_time {0};
    int total_running_time_change {0};

    for (auto barista: barista_list){
        if (total_running_time_change == 0){
            total_running_time = barista->work_start + barista->working_time;
            total_running_time_change++;
        }

        if (barista->work_start + barista->working_time > total_running_time){
            total_running_time = barista->work_start + barista->working_time;
        }
    }

    cout << " 330 total running time: " << total_running_time;
}
