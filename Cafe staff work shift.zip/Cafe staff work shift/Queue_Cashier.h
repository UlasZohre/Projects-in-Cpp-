//
// Created by ulasz on 3.12.2022.
//

#ifndef ASM3_QUEUE_CASHIER_H
#define ASM3_QUEUE_CASHIER_H

#include "Customer.h"
#include "Queue_Barista.h"
class Queue_Cashier {
public:
    Queue_Cashier();//normal queue

    Customer* pop();//delete from beginning

    void emplace(Customer* cust);//add element to end

    int size;

    Customer* Head;

    Customer* Last;

    int max_size;



};


#endif //ASM3_QUEUE_CASHIER_H
