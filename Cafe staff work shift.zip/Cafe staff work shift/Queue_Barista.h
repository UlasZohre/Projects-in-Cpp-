//
// Created by ulasz on 3.12.2022.
//

#ifndef ASM3_QUEUE_BARISTA_H
#define ASM3_QUEUE_BARISTA_H

#include "Customer.h"

class Queue_Barista {
public:

    Queue_Barista();//priority queue

    Customer* pop();//delete from beginning

    void emplace(Customer* cust);//add element to end

    int size;

    int max_size;

    Customer* Head;

    Customer* Last;


};


#endif //ASM3_QUEUE_BARISTA_H
