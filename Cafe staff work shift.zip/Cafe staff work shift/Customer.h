//
// Created by ulasz on 2.12.2022.
//

#ifndef ASM3_CUSTOMER_H
#define ASM3_CUSTOMER_H


class Customer {
public:
    Customer(double arrival_time_in, double order_time_in, double brew_time_in, double order_price_in);
    double arrival_time;
    double order_time;
    double brew_time;
    double order_price;
    double waiting_time;
    int waiting_time_change_cashier;
    double barista_waiting_time;
    int waiting_time_change_barista;
    int cashier_id;
    double arriving_barista_time;
    double served;
    bool customer_in_queue;
    int barista_id ;
    double customer_took_its_order;
    Customer* next;
    Customer* prev;

    bool CompareCustomer(Customer* cust1, Customer* cust2);
};


#endif //ASM3_CUSTOMER_H
