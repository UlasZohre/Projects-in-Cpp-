//
// Created by ulasz on 2.12.2022.
//

#include "Staff.h"

Staff::Staff(){
    working_time = 0;
    is_avail = true;
    work_start = 0;
    how_many_customer= 0;
    time_until_avail = 0;
    customer = nullptr;
}