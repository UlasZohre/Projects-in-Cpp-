//
// Created by ulasz on 3.12.2022.
//

#ifndef ASM3_MODETWO_H
#define ASM3_MODETWO_H
#include <vector>
#include "Customer.h"
#include "Staff.h"
using namespace std;
#include <fstream>
#include "Queue_Barista.h"
#include "Queue_Cashier.h"
#include <iostream>


class ModeTwo {
public:
    ModeTwo(fstream &input, fstream &output);

};


#endif //ASM3_MODETWO_H
