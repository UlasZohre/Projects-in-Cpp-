//
// Created by ulasz on 6.12.2022.
//

#ifndef ASM3_MODEONE_H
#define ASM3_MODEONE_H

#include <vector>
#include <iostream>
#include "Customer.h"
#include "Staff.h"
#include "Queue_Barista.h"
#include "Queue_Cashier.h"
#include <fstream>

using namespace std;

class ModeOne {
public:
    ModeOne(fstream &input, fstream &output);
};


#endif //ASM3_MODEONE_H
