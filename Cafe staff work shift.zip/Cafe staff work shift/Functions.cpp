//
// Created by ulasz on 7.12.2022.
//

#include "Functions.h"


bool Functions::CompareCustomer(Customer *cust1, Customer *cust2) {
    return (cust1->arriving_barista_time < cust2->arriving_barista_time);
}

Staff* Functions::find_next_barista(std::vector<Staff*> barista_list){
    Staff* temp = barista_list[0];
    for (auto barista: barista_list){
        if (temp->time_until_avail> barista->time_until_avail){
            temp = barista;
        }
    }

    return temp;
}