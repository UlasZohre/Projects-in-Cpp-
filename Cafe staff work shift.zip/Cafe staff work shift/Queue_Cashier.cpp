//
// Created by ulasz on 3.12.2022.
//

#include "Queue_Cashier.h"


Queue_Cashier::Queue_Cashier() {
    size = 0;
    max_size = 0;
    Head = nullptr;
    Last = nullptr;
}

Customer* Queue_Cashier::pop() {

    Customer *temp = Head;// we will return this one

    if (Head == nullptr){
        return temp;
    }
    else{
        if (Head->prev != nullptr){
            Head->prev->next = nullptr;//when head of queue depart one after him will be new head
            Head = Head->prev;//updating head

        }

        else{
            Head = nullptr;
        }
    }


    size--;//queue is one less now
    return temp;
}

void Queue_Cashier::emplace(Customer* cust) {

    if (Head == nullptr){//if queue is empty we will add customer to its beginning
        Head = cust;
        Last = cust;
    }

    else if (Head == Last){//if queue has just one customer, and we are adding another one
        Head->prev = cust;
        cust->next = Head;
        Last = cust;
    }

    else{//queue has more than one customer
        Last->prev = cust;
        cust->next = Last;
        Last = cust;
    }

    size++;//we are adding one to size

    if (size > max_size){// we are updating max size if size is bigger than max size
        max_size = size;
    }

}
