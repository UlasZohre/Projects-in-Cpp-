//
// Created by ulasz on 7.12.2022.
//

#ifndef ASM3_FUNCTIONS_H
#define ASM3_FUNCTIONS_H
#include "Customer.h"
#include "Staff.h"
#include <vector>


class Functions {

public:
    bool CompareCustomer(Customer *cust1, Customer *cust2);
    Staff* find_next_barista(std::vector<Staff*> barista_list);
};


#endif //ASM3_FUNCTIONS_H
