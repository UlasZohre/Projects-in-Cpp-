#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Customer.h"
#include "Staff.h"
#include "ModeOne.h"
#include "ModeTwo.h"
#include <algorithm>
using namespace std;

int main(int argc, char* argv[]) {

    fstream input;// opening input file
    input.open("../input1");

    if (!input.is_open()){
        cout << "Input could not open.";
        return 1;
    }

    fstream output;

    ModeOne(input, output);


    ModeTwo(input, output);



    input.close();
    output.close();
    return 0;
}
