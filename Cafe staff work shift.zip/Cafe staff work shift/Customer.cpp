//
// Created by ulasz on 2.12.2022.
//

#include "Customer.h"

using namespace std;

Customer::Customer(double arrival_time_in, double order_time_in, double brew_time_in, double order_price_in) {

    arrival_time =arrival_time_in;
    order_time = order_time_in;
    brew_time = brew_time_in;
    order_price = order_price_in;
    waiting_time = 0;
    waiting_time_change_cashier =0;
    waiting_time_change_barista = 0;
    barista_waiting_time = 0;
    cashier_id = 0;
    arriving_barista_time = 0;
    served = 0;
    customer_in_queue = false;
    barista_id = 0;
    customer_took_its_order = 0;
    next = nullptr;
    prev = nullptr;

}
