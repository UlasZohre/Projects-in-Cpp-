//
// Created by ulasz on 2.12.2022.
//

#ifndef ASM3_STAFF_H
#define ASM3_STAFF_H
#include "Customer.h"

class Staff {
public:
    Staff();
    double working_time;
    bool is_avail;
    double work_start ;
    int how_many_customer;
    Customer* customer;
    double time_until_avail;


};


#endif //ASM3_STAFF_H
