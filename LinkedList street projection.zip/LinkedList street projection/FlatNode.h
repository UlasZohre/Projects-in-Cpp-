//
// Created by ulasz on 14.11.2022.
//

#ifndef ASM2_FLATNODE_H
#define ASM2_FLATNODE_H


class FlatNode {
public:
    FlatNode(int ID, int initial_Bandwith);

    int FlatID;

    FlatNode *prev;
    FlatNode *next;

    int initial_Bandwith;

    int is_Empty;


};




#endif //ASM2_FLATNODE_H
