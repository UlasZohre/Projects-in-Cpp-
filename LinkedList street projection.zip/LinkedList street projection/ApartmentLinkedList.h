//
// Created by ulasz on 16.11.2022.
//

#ifndef ASM2_APARTMENTLINKEDLIST_H
#define ASM2_APARTMENTLINKEDLIST_H
#include "ApartmentNode.h"
#include <string>
#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

class ApartmentLinkedList {

public:

    ApartmentNode *head;

    int size;

    ApartmentLinkedList();

    void Split_(string where, string* arr);

    vector<int> Split(string where );

    void Add_Apartment(ApartmentNode *node, string where);

    void Remove_Apartment(string name);

    int Find_Sum_Max_Bandwidht(fstream &output);

    void Merge_Apartments(ApartmentNode *apt1, ApartmentNode *apt2);

    void Relocate(ApartmentNode* temp, int locateBeforeID, string list_of_flats );

    void List_Apartments(fstream &output);

    void Make_Flat_Empty(ApartmentNode *temp, int ID);

    ApartmentNode* FindApt(string name, ApartmentNode *temp);

    ~ApartmentLinkedList();

};


#endif //ASM2_APARTMENTLINKEDLIST_H
