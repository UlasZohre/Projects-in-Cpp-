#include <iostream>
#include <fstream>
#include <string>
#include "FlatNode.h"
#include "FlatLinkedList.h"
#include "ApartmentNode.h"
#include "ApartmentLinkedList.h"


using namespace std;

void SplitTab(string line, string* arr){

    string temp_command {};// we will read char by char and add them to this
    int arr_index {0};// we need to track which index we are on with array

    for (int char_size = 0; char_size< line.size() ; char_size++){

        if (line[char_size] != '\t' ){// if it is not tab we will add them
            temp_command += line[char_size];

        }

        else if (line[char_size] == '\t' ){// if it is tab we will add temp to arr and refresh it

            arr[arr_index] = temp_command;
            arr_index++;

            temp_command = "";
        }

        if (char_size == line.size()-1){// we need to check this seperatly because if we do not it will not get last temp

            arr[arr_index] = temp_command;
            arr_index++;

            temp_command = "";
        }
    }
}

int main(int argc, char* argv[]) {

    ApartmentLinkedList *apt = new ApartmentLinkedList();

    ifstream input;// opening the file
    input.open(argv[1]);

    if(!input.is_open()){
        cout << "Input file could not open." << endl;// checking if file is really open
        return 1;
    }

    string line {};// we will read line by line
    int counter = 1;
    string commands[5] {};// we need to add commands to a
    /*commands[0] command
     * commands[1] apt name
     * commands[2] index
     * commands[3] widht
     * commands[4] flat id
     */


    fstream output(argv[2], ios::out);

    if (!output.is_open()){
        cout << "Output file could not open." << endl;
        return 1;
    }

    while (getline(input, line)){// getting a line from input file
        cout << counter << endl;
        SplitTab(line, commands);// a function for splitting from tabs

        if (commands[0]== "add_apartment"){

            string name = commands[1];
            string where = commands[2];

            int Max_Bandwidth =stoi(commands[3]) ;

            ApartmentNode *node = new ApartmentNode(name, Max_Bandwidth);// will create new apartment node

            apt->Add_Apartment(node, where);

       }

       else if (commands[0] == "add_flat"){

            string AptName = commands[1];

            int index = stoi(commands[2]);
            int initial_width = stoi(commands[3]);
            int ID = stoi(commands[4]);

            ApartmentNode *temp = apt->head;
            temp = apt->FindApt(AptName, temp);// will find the apartment that will work on

            FlatNode *node = new FlatNode(ID, initial_width);

            if (temp->remaining_bandwith - initial_width < 0){//checking the bandwidht
                node->initial_Bandwith = temp->remaining_bandwith;
            }



            if (temp->flatList == nullptr){
                FlatLinkedList *AptFlatList = new FlatLinkedList();//if apartment has no flat list we will create and assign
                temp->flatList = AptFlatList;

                temp->flatList->Add_Flat(node, index);//adding flat to flat list
            }


            else{
                temp->flatList->Add_Flat(node, index);
            }

            temp->remaining_bandwith = temp->remaining_bandwith - initial_width;//updating the bandwidhts
       }

       else if (commands[0] == "remove_apartment"){

           string AptName = commands[1];

           apt->Remove_Apartment(AptName);

       }

       else if (commands[0] == "make_flat_empty"){

            string AptName = commands[1];

            int ID = stoi(commands[2]);

            ApartmentNode *temp = apt->head;

            temp = apt->FindApt(AptName, temp);//finding the apartment we will work on

            apt->Make_Flat_Empty(temp, ID);
       }

       else if (commands[0] == "find_sum_of_max_bandwidths"){

           apt->Find_Sum_Max_Bandwidht(output);
       }

       else if (commands[0] == "merge_two_apartments"){


           string Apt1 = commands[1];
           string Apt2 = commands[2];

           ApartmentNode * apt1 = apt->head;//temp pointer for apartment 1
           apt1 = apt->FindApt(Apt1, apt1);

           ApartmentNode *apt2 = apt->head;
           apt2 = apt->FindApt(Apt2, apt2);//temp pointer for apartment 2


           apt->Merge_Apartments(apt1, apt2);
       }

       else if (commands[0] == "relocate_flats_to_same_apartment"){

            string AptName = commands[1];
            string list_of_flats = commands[3];

            int locateBeforeID = stoi(commands[2]);

            ApartmentNode *temp = apt->head;

            temp = apt->FindApt(AptName, temp);

            apt->Relocate(temp, locateBeforeID, list_of_flats);
       }

       else if (commands[0] == "list_apartments"){

            apt->List_Apartments(output);
       }
       counter++;
    }

    input.close();
    output.close();
    return 0;
}
