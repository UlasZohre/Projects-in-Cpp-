//
// Created by ulasz on 16.11.2022.
//

#include "ApartmentLinkedList.h"
#include "ApartmentNode.h"
#include "FlatLinkedList.h"
#include "FlatNode.h"
#include <vector>
#include <string>

using namespace std;

ApartmentLinkedList::ApartmentLinkedList() {

    head = nullptr;
    size = 0;
}

void ApartmentLinkedList::Split_(string where, string *arr) {

    string temp_command {};

    int arr_ind {0};

    for (int char_size = 0; char_size< where.size() ; char_size++){
        if (where[char_size] != '_' ){// if it is not tab we will add them
            temp_command += where[char_size];

        }

        else if (where[char_size] == '_' ){// if it is tab we will add temp to arr and refresh it

            arr[arr_ind] = temp_command;
            arr_ind++;

            temp_command = "";
        }

        if (char_size == where.size()-1){// we need to check this seperatly because if we do not it will not get last temp

            arr[arr_ind] = temp_command;
            arr_ind++;

            temp_command = "";
        }
    }
}

vector<int> ApartmentLinkedList::Split(string where) {//4 2 13

    vector<int> v;
    std::string delimiter= "]";
    where.erase(where.find(delimiter));
    where.erase(0, 1);
    std::string delimiter_char = ",";
    size_t pos = 0;
    std::string token;
    while ((pos = where.find(delimiter_char)) != std::string::npos) {
        token = where.substr(0, pos);
        v.push_back(stoi(token));
        where.erase(0, pos + delimiter_char.length());
    }
    v.push_back(stoi(where));

    return v;

    /*string command {};

    for (int char_size = 0; char_size < where.size(); char_size++){

        if(where[char_size] != '[' && where[char_size] != ']' && where[char_size] != ','){

            command += where[char_size];
        }

        else if (where[char_size] == '[' || where[char_size] == ',' || where[char_size] == ']'){

            cout << command << " all 68"<< endl;
            vec.push_back(stoi(command));
            command = "";
        }

    }

    /*string delimiter = "]";
    where.erase(where.find(delimiter));

    where.erase(0,1);

    delimiter = ",";
    size_t pos= 0;
    string token;

    while ((pos = where.find(delimiter)) != string::npos) {
        token = where.substr(0, pos);
        vec.push_back(stoi(token));
        where.erase(0, pos + delimiter.length());
        vec.push_back(stoi(where));
        for(auto x:vec) cout<<x<<endl;

    }*/




}

void ApartmentLinkedList::Add_Apartment(ApartmentNode *node, string where) {

    string *arr = new string [2];

    if (head == nullptr){// if head is empty where to place is unimportant since we place it on the head anyway

        head = node;
        head->next = head;
    }

    else{

        ApartmentNode *temp = head;
        Split_(where, arr);

        string BoA = arr[0];//BoA == before or after
        string name = arr[1];

        if (BoA == "before"){

            while (temp->ApartmentName != name){//we will search apartments from their names
                temp = temp->next;

            }
            if (temp->prev != nullptr){
                temp->prev->next = node;
            }

            node->prev = temp->prev;
            temp->prev = node;
            node->next = temp;

            if ( temp == head){//this is a special case if we are adding apartment before head it will become new head
                               //and last node will point new head

                ApartmentNode *temp2 = head;

                for (int counter = 0; counter < size; counter++){//to get last node we need a loop

                    temp2 = temp2->next;
                }

                temp2->next = node;//temp2 is the last node and now it points node
                head = node;//new head is node
            }
        }

        else if ( BoA == "after"){

            while (temp->ApartmentName != name){
                temp = temp->next;
            }

            node->next = temp->next;
            temp->next = node;
            node->prev = temp;
        }
    }
    size++;
}

int ApartmentLinkedList::Find_Sum_Max_Bandwidht(fstream &output) {

    ApartmentNode *temp = head;

    int total {0};

    for (int counter = 0; counter < size; counter++){//size is the element number of apartment linked list

        total += temp->Max_bandwith;
        temp = temp->next;
    }

    output <<"sum of bandwidths: " << total << endl;
    output << endl;

    return total;

}

void ApartmentLinkedList::Remove_Apartment(string name) {

    ApartmentNode *temp = head;// temp pointer for finding apartment

    while (temp->ApartmentName != name){// will search apartment until find the correct name

        temp = temp->next;
    }

    if (temp->prev != nullptr){//updating connections
        temp->prev->next = temp->next;
    }

    if (temp->next != nullptr){//updating connections
        temp->next->prev = temp->prev;
    }

    if (temp->flatList == nullptr){//if flat list is null then we will delete temp
        delete temp;
    }

    else{
        temp->flatList->Remove_Flat();//if flat list is not null then we will delete everything in it
        delete temp;//then we will delete temp and the apartment by it
    }

    size --;// shrinking down the size

}

void ApartmentLinkedList::List_Apartments(fstream &output) {

    ApartmentNode *temp = head->next;//we will take head as a special case because it is a special case
    output << head->ApartmentName << "(" << head->Max_bandwith << ")\t";
    if(head->flatList != nullptr){// if head has a flat list then we will write them first
        head->flatList->FlatList(output);

    }

    if (head->flatList == nullptr){// if it has no flat list we are good
        output << endl;
    }

    while(temp != head ){//it is a circular list so we need to next of head and iterate untill we find head
                        //that is why we take head as a special case
        output << temp->ApartmentName << "(" << temp->Max_bandwith << ")\t";//printing their assests
        if (temp->flatList != nullptr){
            temp->flatList->FlatList(output);
        }

        else{
            output << endl;
        }
        temp = temp->next;// to break while
    }
    output << endl;
}

void ApartmentLinkedList::Merge_Apartments(ApartmentNode *apt1, ApartmentNode *apt2) {

    if (apt1->flatList == nullptr){//if it has no flat list we will create and assign it
        FlatLinkedList *AptFlatList = new FlatLinkedList();
        apt1->flatList = AptFlatList;
    }

    if ( apt1->flatList->Head != nullptr){//if head is not null pointer then we will need to update connections
        FlatNode* apt1_last = apt1->flatList->Head;
        while (apt1_last->next != nullptr){
            apt1_last = apt1_last->next;
        }

        if (apt2->flatList != nullptr){
            apt1_last->next = apt2->flatList->Head;
            apt2->flatList->Head->prev = apt1_last;
        }
    }

    else{
        apt1->flatList->Head = apt2->flatList->Head;//if head is null pointer then we just assign head to head
    }

    apt2->flatList = nullptr;//we will delete apt so we need to get rid of its flat list value

    apt1->Max_bandwith = apt1->Max_bandwith + apt2->Max_bandwith;//updating bandwidth
    apt1->remaining_bandwith = apt2->remaining_bandwith + apt1->remaining_bandwith;

    this->Remove_Apartment(apt2->ApartmentName);//delete apt2
}

void ApartmentLinkedList::Relocate(ApartmentNode* temp, int locateBeforeID, string list_of_flats) {

    vector<int> vec = Split(list_of_flats);;//splitting [4,2,13] like inputs
    vector<FlatNode*> FL;//will contain necessary flats

    for (int i = 0; i < vec.size(); i++){//iterating for every element in vec

        int temp_flatID = vec[i];//will contain necessary flat id

        FlatNode *temp_flat2 = head->flatList->Head;//will contain head's flat list's Head

        if(head->flatList != nullptr){// if head's flat list is null pointer


            while(temp_flat2->FlatID != temp_flatID && temp_flat2->next != nullptr){//will iterate untill find true flat

                temp_flat2 = temp_flat2->next;
            }


            if(temp_flat2->FlatID == temp_flatID){//after here we will just update some connections if they are true
                if (temp_flat2->prev != nullptr && temp_flat2->next != nullptr){

                    temp_flat2->prev->next = temp_flat2->next;
                    temp_flat2->next->prev = temp_flat2->prev;
                }

                else if (temp_flat2->prev == nullptr && temp_flat2->next != nullptr){

                    temp_flat2->next->prev = temp_flat2->prev;
                    head->flatList->Head = temp_flat2->next;
                }

                else if (temp_flat2->prev != nullptr && temp_flat2->next == nullptr){
                    temp_flat2->prev->next= temp_flat2->next;
                }

                else if (temp_flat2->prev == nullptr && temp_flat2->next == nullptr){

                    head->flatList = nullptr;
                }

                head->Max_bandwith -= temp_flat2->initial_Bandwith;
                FL.push_back(temp_flat2);
            }
        }

        ApartmentNode *temp_apt = head->next;

        while(temp_apt != head){// same again but for every other apt in list except head

            FlatNode *temp_flat = temp_apt->flatList->Head;

            if (temp_apt->flatList != nullptr){
                while(temp_flat->FlatID != temp_flatID && temp_flat->next != nullptr){

                    temp_flat = temp_flat->next;
                }

                if (temp_flat->FlatID == temp_flatID){

                    if (temp_flat->prev != nullptr && temp_flat->next != nullptr){
                        temp_flat->prev->next = temp_flat->next;
                        temp_flat->next->prev = temp_flat->prev;
                    }

                    else if (temp_flat->prev == nullptr && temp_flat->next != nullptr){

                        temp_flat->next->prev = temp_flat->prev;
                        temp_apt->flatList->Head = temp_flat->next;
                    }

                    else if (temp_flat->prev != nullptr && temp_flat->next == nullptr){

                        temp_flat->prev->next = temp_flat->next;
                    }

                    else if (temp_flat->prev == nullptr && temp_flat->next == nullptr){

                        temp_apt->flatList = nullptr;
                    }
                    temp_apt->Max_bandwith -= temp_flat->initial_Bandwith;
                    FL.push_back(temp_flat);
                }
            }
            temp_apt = temp_apt->next;
        }
    }

    int index = 0;

    for (int i = 1; i < FL.size(); i++){// updating connection in linked list

        FL[i-1]->next = FL[i];

        FL[i]->prev = FL[i-1];
        index = i;
    }

    FlatNode *add_node = temp->flatList->Head;//will contain the node we will work on before it
    int total = 0;

    for (int i = 0 ; i < FL.size(); i++){
        total = total + FL[i]->initial_Bandwith;
    }

    temp->Max_bandwith += total;

    while(add_node->FlatID != locateBeforeID){//searching for true flat id

        add_node = add_node->next;
    }

    if(add_node->prev == nullptr ){

        add_node->prev = FL[index];
        FL[index]->next = add_node;
        temp->flatList->Head = FL[0];
    }

    else if(add_node->prev != nullptr){

        add_node->prev->next = FL[0];
        FL[0]->prev = add_node->prev;
        FL[index]->next = add_node;
        add_node->prev = FL[index];
    }

    temp->flatList->size += FL.size();
}

ApartmentNode* ApartmentLinkedList::FindApt(string name, ApartmentNode *temp) {

    while (temp->ApartmentName != name){//searching for correct name in apartments
        temp = temp->next;
    }

    return temp;
}

void ApartmentLinkedList::Make_Flat_Empty(ApartmentNode *temp, int ID){

    int initial = 0;//to update bandwidth
    initial = temp->flatList->Empty_Flat(ID, initial);//empty function

    temp->remaining_bandwith = temp->remaining_bandwith + initial;//updating bandwidth
}