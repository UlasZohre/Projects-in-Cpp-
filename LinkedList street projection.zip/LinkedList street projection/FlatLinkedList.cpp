//
// Created by ulasz on 14.11.2022.
//

#include "FlatLinkedList.h"
#include <iostream>

using namespace std;
FlatLinkedList::FlatLinkedList() {// constructor for assigning values for head and size
    Head = nullptr;
    size = 0;
}

void FlatLinkedList::Add_Flat(FlatNode *node, int index){//add flat function

    if (Head == nullptr){//if head is empty that means linked list is empty

        Head = node;

    }

    else{

        FlatNode *temp = Head;// we ll use this one later on with it iterations

        if (index > size){// if index is bigger than size of our linked list we need to add it to at the end

            for (int counter = 0; counter < size; counter++){//iteration on size variable, we need to do to add
                                                               // -1 otherwise we ll get segmentation fault
                temp = temp->next;
            }

            temp->next = node;//node's prev and next pointers are nullpointer by default so no need to change them
            node->prev = temp;

        }

        else if (index == 0){// case of we are adding node to beginning of linked list

            node->next = Head;
            Head->prev = node;
            Head = node;
        }

        else{
            for (int counter = 1; counter < index; counter++){
                temp = temp -> next;
            }

            node->next = temp->next;

            if (temp->next != nullptr){
                temp->next->prev = node;
            }


            temp->next = node;
            node->prev = temp;

        }

    }
    size++;// we increase size of linked list everytime we add something

}

int FlatLinkedList::Empty_Flat(int ID, int initial) {

    FlatNode *temp = Head;

    while (temp->FlatID != ID){// will iterate until find true flat
        temp = temp->next;
    }
    initial = temp->initial_Bandwith;
    temp->initial_Bandwith = 0;
    temp->is_Empty = 1;

    return initial;
}

FlatLinkedList* FlatLinkedList::Remove_Flat() {

    FlatNode* temp = Head;

    while (temp->next != nullptr){
        temp = temp->next;
        delete temp->prev;

    }

    delete temp;// this deletes temp pointer
    delete Head;
    return nullptr;
}


void FlatLinkedList::FlatList(fstream &output) {
    FlatNode * temp = Head;

    while (temp != nullptr){
        output << "Flat" << temp->FlatID << "(" << temp->initial_Bandwith << ")\t";
        temp = temp->next;
    }

    output << endl;

}

