//
// Created by ulasz on 14.11.2022.
//

#include "FlatNode.h"


FlatNode::FlatNode(int ID, int Bandwith) {

    FlatID = ID;
    initial_Bandwith = Bandwith;

    is_Empty = 0;

    next = nullptr;
    prev = nullptr;
}



