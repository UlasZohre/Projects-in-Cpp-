//
// Created by ulasz on 14.11.2022.
//

#ifndef ASM2_FLATLINKEDLIST_H
#define ASM2_FLATLINKEDLIST_H

#include "FlatNode.h"
#include <fstream>

class FlatLinkedList {
public:
FlatLinkedList();

    void Add_Flat(FlatNode *node, int index);

    int Empty_Flat(int ID, int initial);

    int size;

    FlatLinkedList* Remove_Flat();

    FlatNode *Head;

    void FlatList(std::fstream &output);


};


#endif //ASM2_FLATLINKEDLIST_H
