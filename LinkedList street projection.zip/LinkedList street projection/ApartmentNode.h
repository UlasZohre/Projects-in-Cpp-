//
// Created by ulasz on 16.11.2022.
//

#ifndef ASM2_APARTMENTNODE_H
#define ASM2_APARTMENTNODE_H

#include <string>
#include "FlatLinkedList.h"

class ApartmentNode {
public:

    ApartmentNode(std::string name, int bandwidth );

    std::string ApartmentName;

    FlatLinkedList *flatList;

    int Max_bandwith;

    int remaining_bandwith;

    ApartmentNode *next;

    ApartmentNode *prev;
};


#endif //ASM2_APARTMENTNODE_H
