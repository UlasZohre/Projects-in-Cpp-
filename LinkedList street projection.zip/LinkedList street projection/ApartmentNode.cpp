//
// Created by ulasz on 16.11.2022.
//
#include <string>
#include "ApartmentNode.h"

using namespace std;
ApartmentNode::ApartmentNode(string name, int bandwidth ) {

    ApartmentName = name;

    flatList = nullptr;

    remaining_bandwith = bandwidth;
    Max_bandwith = bandwidth;

    next = nullptr;
    prev = nullptr;// to make it easier on accessing before

}